exports.helloGET = (req, res) => {
    console.log('Hello, World!');
    res.send('Hello, World!');
};